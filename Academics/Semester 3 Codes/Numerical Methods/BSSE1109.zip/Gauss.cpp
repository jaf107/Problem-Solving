#include<bits/stdc++.h>
using namespace std;
int main()
{
    ifstream input;
    ofstream output;
    input.open("input.txt", ios::in);
    output.open("output.txt", ios::out);

    int c= 2;
    while(c--)
    {
        int n;
        input>>n;

        double mat[n][n+1];
        double x[n];

        for(int i=0 ; i<n; i++)
        {
            for(int j=0; j<=n ; j++)
            {
//                scanf("%d",&input);
                input>>mat[i][j];
            }
        }

        // SWAPPING
        for(int i=0; i<n; i++)
        {
            for(int j = i+1; j<n; j++)
            {
                if(abs(mat[i][i]) < abs(mat[j][i]))
                {
                    for(int k =0; k<=n ; k++)
                    {
                        mat[i][k] = mat[i][k] + mat[j][k];
                        mat[j][k] = mat[i][k] - mat[j][k];
                        mat[i][k] = mat[i][k] - mat[j][k];
                    }
                }
            }
        }

        double pivot = 0;
        for(int i = 0; i < n-1; i++)
        {
            for(int j = i+1 ; j<n ; j++)
            {
                pivot = mat[j][i] / mat[i][i];
                for(int k = 0; k<= n; k++)
                {
                    mat[j][k] = mat[j][k] - (pivot* mat[i][k]);
                }
            }
        }

        //BACKWARD SUBSTITUTION
        x[n-1] = mat[n-1][n] / mat[n-1][n-1];

        for(int i = n-2; i >= 0; i--)
        {
            x[i] = mat[i][n];
            for(int j = i+1 ; j < n; j++)
            {
                if(i!= j)
                {
                    x[i] = x[i] - (mat[i][j] * x[j]);
                }
            }
            x[i] /= mat[i][i];
        }

        for(int i=0; i<n; i++)
        {
            output<<x[i]<<", ";
        }
        output<<endl;
    }
}


